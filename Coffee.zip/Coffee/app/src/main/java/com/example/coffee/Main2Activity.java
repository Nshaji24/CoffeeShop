package com.example.coffee;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class Main2Activity extends AppCompatActivity {
    private Button buyButton;
    private TextView txtv,ovrTOT ;
    private EditText numCups;
   public double oz9tot;
    double ovrTOTnum1;
    private double oz9Price =1.75;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        numCups= (EditText)findViewById(R.id.editText2) ;
        ovrTOT=findViewById(R.id.ovrTOT);
        txtv= findViewById(R.id.textView5);
        buyButton= (Button)findViewById(R.id.buybutton);
        buyButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int num = Integer.parseInt(numCups.getText().toString());
                 oz9tot= num*oz9Price;
             ovrTOTnum1=ovrTOTnum1+num;
                txtv.setText(String.valueOf(oz9tot));
                ovrTOT.setText(String.valueOf(ovrTOTnum1));


            }

        });


    }
}
