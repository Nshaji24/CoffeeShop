package com.example.coffee;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class oz15activity extends AppCompatActivity {
private Button buy12;
private EditText cupNum;
private TextView tot15;
public double oz15tot;
double oz15price=1.90;
    double ovrTOTnum15;
    private TextView finalTot15;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_oz15activity);
        buy12 = (Button)findViewById(R.id.buy15);
        cupNum=(EditText)findViewById(R.id.CupNum);
        tot15=findViewById(R.id.total15);
        buy12.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int num15= Integer.parseInt(cupNum.getText().toString());
                oz15tot= num15*oz15price;
                tot15.setText(String.valueOf(oz15tot));
                finalTot15 =(TextView)findViewById(R.id.totalcups15) ;
                ovrTOTnum15 = ovrTOTnum15 + num15;
                finalTot15.setText(String.valueOf(ovrTOTnum15));
            }
        });
    }
}
