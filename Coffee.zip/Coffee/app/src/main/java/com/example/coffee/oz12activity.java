package com.example.coffee;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class oz12activity extends AppCompatActivity {
    private Button buyButton12;
    private TextView txtv12 ;
    private EditText numCups12;
   public double oz12tot;
    private double oz12Price =1.90;
    double ovrTOTnum12;
    private TextView finalTot;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_oz12activity);
        numCups12= (EditText)findViewById(R.id.cupNum12) ;

        txtv12= findViewById(R.id.tot12);
        buyButton12= (Button)findViewById(R.id.buy12);
        buyButton12.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int num = Integer.parseInt(numCups12.getText().toString());
                oz12tot= num*oz12Price;
                txtv12.setText(String.valueOf(oz12tot));
                finalTot =(TextView)findViewById(R.id.finaltot) ;
                ovrTOTnum12 = ovrTOTnum12 + num;
                finalTot.setText(String.valueOf(ovrTOTnum12));

            }
        });


    }
}
