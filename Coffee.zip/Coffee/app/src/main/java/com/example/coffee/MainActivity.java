package com.example.coffee;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentProviderOperation;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.PopupWindow;
import android.widget.Toast;

import java.util.zip.Inflater;

public class MainActivity extends AppCompatActivity {
private Button oz9button;
private Button oz12button;
private Button oz15Button;
private Button Help;
private PopupWindow popupWindow;
private LayoutInflater layoutInflater;
//private Button totcup,totMoney;
private int oz9count,oz12count,oz15count,totCount;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


       // totMoney=(Button)findViewById(R.id.totMoney);
        Help = (Button)findViewById(R.id.help) ;
        Help.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            }
        });
        oz15Button =(Button)findViewById(R.id.oz15);
        oz15Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                open15oz();
            }
        });
        oz12button= (Button)findViewById(R.id.oz12);
        oz12button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                open12oz();
            }
        });
        oz9button = (Button)findViewById(R.id.oz9) ;
        oz9button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                open9oz();
            }
        });
    }

    private void open15oz() {
        Intent intent3 = new Intent(this,oz15activity.class
        );
        startActivity(intent3);
        oz15count++;
    }

    public void open9oz (){
        Intent intent =new Intent(this,Main2Activity.class);
        startActivity(intent);
        oz9count++;

    }
    public void open12oz(){
        Intent intent2 = new Intent( this,oz12activity.class
        );
        startActivity(intent2);
        oz12count++;
    }
}
